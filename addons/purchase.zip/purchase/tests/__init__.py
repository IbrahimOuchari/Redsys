# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_purchase
from . import test_purchase_order_report
from . import test_purchase_invoice
from . import test_access_rights
from . import test_accrued_purchase_orders
from . import test_purchase_tax_totals
from . import test_purchase_dashboard
